import java.lang.Object;
import java.util.Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import Thor.API.tcResultSet;
import Thor.API.tcUtilityFactory;
import Thor.API.Exceptions.tcAPIException;
import Thor.API.Exceptions.tcColumnNotFoundException;
import Thor.API.Operations.tcFormInstanceOperationsIntf;
import Thor.API.Operations.tcFormDefinitionOperationsIntf;
import Thor.API.Operations.tcUserOperationsIntf;
import com.thortech.xl.dataobj.tcDataSet;
import com.thortech.xl.dataobj.util.tcProcessUtilities;
import com.thortech.xl.util.config.ConfigurationClient;
import Thor.API.Operations.tcObjectOperationsIntf;
import com.thortech.xl.vo.ResourceData;
import com.thortech.xl.dataaccess.tcDataProvider;
import com.thortech.xl.dataaccess.tcDataSetException;
import com.thortech.util.logging.Logger;

  public class FindRacfREVOKEGroup {

    tcUserOperationsIntf userClient = null;
    tcFormInstanceOperationsIntf formClient = null;
    tcFormDefinitionOperationsIntf fdefClient = null;
    tcUtilityFactory tcFactory = null;

     public static void main(String[] args) throws Exception {
       Logger logger = Logger.getLogger("Sample");
       System.out.println("...........Calling configuration Client.........");
       Properties jndi = ConfigurationClient.getComplexSettingByPath("Discovery.CoreServer").getAllSettings();
       tcUtilityFactory tcFactory = new tcUtilityFactory(jndi, "xelsysadm", "Idmsc123");
       tcUserOperationsIntf userClient = (tcUserOperationsIntf)tcFactory.getUtility("Thor.API.Operations.tcUserOperationsIntf");
       tcFormInstanceOperationsIntf tcFormOp = (tcFormInstanceOperationsIntf)tcFactory.getUtility("Thor.API.Operations.tcFormInstanceOperationsIntf");
       //tcFormDefinitionOperationsIntf fdefClient = (tcFormDefinitionOperationsIntf)tcFactory.getUtility("Thor.API.Operations.tcFormDefinitionOperationsIntf");

         Map usermap = new HashMap();
         usermap.put("Users.User ID", "A777777");
         tcResultSet ts = userClient.findAllUsers(usermap);                                                        // Get All Users
         int NumRec = ts.getRowCount();                                                                            // Get number of User records
         System.out.println("User records " + NumRec);                                                                               // Display the number of User records
         for (int t=0 ;t < ts.getRowCount(); t++) {                                                                // Start for loop
             ts.goToRow(t);                                                                                        // go to first record
             System.out.println("Current number is : " + t);
             long ukey = ts.getLongValue("Users.Key");                                                             // Get User Key step 1 in Design Console
             String usrid = ts.getStringValue("Users.User ID");                                                    // Get User ID
	     System.out.println("***************OIM User Record Start:***************");
             System.out.println("User ID is: " + usrid);                                                           // Print OIM User Login
             System.out.println("User Key is: " + ukey);                                                           // Print OIM User Key
	     tcResultSet tsgrp = userClient.getGroups(ukey);                                                       // Get User OIM Groups
             tcResultSet tsobj = userClient.getObjects(ukey);                                                      // Get User Objects
             int objrec = tsobj.getRowCount();
             boolean rcffound = false;
             System.out.println("---------------"+"OIM Racf Object Test"+"---------------");

              RACFObjectTest:
                for (int s=0; s < objrec; s++) {                                                                   // Start For Loop 
                    tsobj.goToRow(s);                                                                              // Go to first record
                    System.out.println("Current record number is : " + s);
                    String objnm = tsobj.getStringValue("Objects.Name");                                           // Get Object Name
                    String rcfobj = objnm.substring(0, 7);
                    String rcfstr = "OIMRacf";                                                                     // Set string for compare
                    System.out.println(rcfobj);
                        if (rcfobj.equals(rcfstr)) {                                                               // Start IF Loop with condition Object Name is OIMRacf
                             rcffound = true;                                                                      // Set boolean value true if condition satisfied
                             System.out.println("Object Name : " + objnm);
                             break RACFObjectTest;                                                                 // Break from group test                                          
                         } else {                                                                                  // else continue test
                           continue RACFObjectTest;     
                         }
                       }
                       if (rcffound) {
                           long prcinstkey = tsobj.getLongValue("Process Instance.Key");                            // Get Process Instance Key
                           long frmDefKey = tcFormOp.getProcessFormDefinitionKey(prcinstkey);                       // Get Process Form Definition Key
                           int iVersion = tcFormOp.getActiveVersion(frmDefKey);                                     // Get Active form Version
                           System.out.println("Process instance Key is: " + prcinstkey);
                           System.out.println("Form Definition Key is: " + frmDefKey);
                           System.out.println("Active Form version is: " + iVersion);
                           //tcResultSet proc = formClient.getProcessFormData(prcinstkey);                          // Get Process Form Data
                           //String formkey = proc.getStringValue("UD_RACF_ADV_KEY");                               // Get Form Key
                           tcResultSet childResult = tcFormOp.getChildFormDefinition(frmDefKey, iVersion);          // Get Child Form Definition
                           long lChldKey = childResult.getLongValue("Structure Utility.Child Tables.Child Key");
                           System.out.println("Child Form Key is: " + lChldKey);
                           tcResultSet childTableData = tcFormOp.getProcessFormChildData(lChldKey, prcinstkey);     // Get Process Form Child Data
                           int NmChldRec = childTableData.getRowCount();                                            // Get Number of Child Form Records
                           System.out.println("Number of RACF groups records is: " + NmChldRec);
                           System.out.println("User " + usrid + " is memberOf " + NmChldRec + " RACF groups");
                           boolean grpfound = false;
                           System.out.println("-------------"+"Revoke Group Test"+"-------------");

                           RevokeGroupTest:                                                                          // Start group test
                            for (int p=0; p < childTableData.getRowCount(); p++) {                                   // Start For Loop for all records in Child Form
                                 System.out.println(p);
                                 childTableData.goToRow(p);                                                          // Go to first record
                                 String grpnm = childTableData.getStringValue("UD_GROUP_MEMBER_OF");                 // Get Group Member Value
                                 String abc = grpnm.substring(2, 7);                                                 // Get substring removing IT Resource value
                                 String xyz = "REVOK";                                                               // Set string for compare
                                 System.out.println(abc);
                                    if (abc.equals(xyz)) {                                                           // Start IF Loop with condition group name contains REVOK
                                        grpfound = true;                                                             // Set boolean value true if condition satisfied
                                        System.out.println(grpnm);
                                        break RevokeGroupTest;                                                       // Break from group test                                          
                                    } else {                                                                         // else continue
                                      continue RevokeGroupTest;     
                                    }
                            }
                            if (grpfound) {                                                                          // if boolean true
                               String rvkgrpnm = childTableData.getStringValue("UD_GROUP_MEMBER_OF");                // Get Group Name
                               System.out.println("User " + usrid + " is a memberOf " + rvkgrpnm + " Group");        // Print that User is a member of REVOKE Group
                            } else {                                                                                 // else
                              System.out.println("User " + usrid + " isn't a memberOf REVOKE Group");                // Print that User is not a member of REVOKE Group
                            }
                            System.out.println("-------------"+"Revoke Group Test finish"+"-------------");          // Stop REVOKE Group Test
                           } else {                                                                                  // else
                             System.out.println("User " + usrid + " doesn't have OIM Racf Object");                  // Print that User is not a member of REVOKE Group
                           }
                           System.out.println("-------------"+"OIM Racf Object Test finish"+"-------------");        // Stop REVOKE Group Test
                 System.out.println("***************OIM User Record Finish:***************");                        // End of User Record
		}
  	System.exit(0);
   }
}